/*
Estudiante: Daniel Josué Rozo Rodríguez
COD: 20222020006
POO - Programa Cajero
*/

package paquete;

public class principal {
    public static void main(String[] args) {
        Cajero ventana1 = new Cajero();
        ventana1.correrv1();
    }
}
