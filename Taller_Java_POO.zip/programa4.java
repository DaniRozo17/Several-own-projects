
package tallerpoo;
import java.util.Scanner;

public class programa4 {
     public void p4(){
      Scanner sc = new Scanner(System.in);
      String sexo, nombre;
      int cont; 
      double aumento, horast, hextras, tarifa, codigo, salario=0, salarion, impuesto;
        
      do{
      System.out.println("Bienvenido, ");
      System.out.println("Ingrese su nombre: ");
       nombre=sc.nextLine();
      System.out.println("Ingrese su codigo: ");
       codigo=sc.nextDouble();
      System.out.println("Ingrese su sexo: ");
       sexo=sc.nextLine();
      System.out.println("Ingrese las horas trabajadas: "); 
       horast=sc.nextDouble();
      System.out.println("Ingrese la tarifa o valor por hora: ");
       tarifa=sc.nextDouble();
      
      //SALARIO BRUTO
	  if(horast<240)
	  {
	  	salario=(horast*tarifa);
	  }
	    if(horast>=240 && horast<300)
	    {
	  	  hextras=(horast-240); //Para saber cuaantas son las horas extra
	  	  aumento=(tarifa*2.5); //El aumento de la tarifa por hora SOLO para las horas extra
		  salario=(240*tarifa)+(hextras*aumento); //Suma de horas con tarifa normal y horas extras con tarifa especial
	    }
	      if(horast>=300)
		  {
	  	     hextras=(horast-240); //Para saber cuaantas son las horas extra
	  	     aumento=(tarifa*1.7); //El aumento de la tarifa por hora SOLO para las horas extra
		     salario=(240*tarifa)+(hextras*aumento); //Suma de horas con tarifa normal y horas extras con tarifa especial
	      }
	   
	   System.out.println("DATOS DE: "+nombre+" ("+sexo+")"+" COD: "+codigo);
	   //IMPUESTOS A TRABAJADORES (acorde a su salario)
	   if(salario<900000)
	   {
	   	  System.out.println("Su salario es menor al minimo ($900.000), por ende no presenta retenciones");
	   	  System.out.println("Su salario bruto acorde a las horas trabajadas y las tarifas establecidas es de: "+salario);
	   	   System.out.println("Su salario neto es de: "+salario); 
	   }
	     if(salario>=900000 && salario<1200000)
	     {  
	       impuesto=(salario*0.05);
	       salarion=(salario-impuesto);
		   System.out.println("Sus retenciones son equivalentes al 5% del salario");
		   System.out.println("Su salario bruto acorde a las horas trabajadas y las tarifas establecidas es de: "+salario);
		   System.out.println("Sus retenciones equivalen a: "+impuesto); 
		    System.out.println("Su salario neto es de: "+salarion); 
		 }
		   if(salario>=1200000 && salario<2000000)
		   {
		     impuesto=(salario*0.10);
	             salarion=(salario-impuesto);
		     System.out.println("Sus retenciones son equivalentes al 10% del salario");
		     System.out.println("Su salario bruto acorde a las horas trabajadas y las tarifas establecidas es de: "+salario);
		     System.out.println("Sus retenciones equivalen a: "+impuesto); 
		      System.out.println("Su salario neto es de: "+salarion); 
		   }
		     else if(salario>=2000000)
		     {
		     	System.out.println("Sus retenciones son equivalentes al 20% del salario");
		     	impuesto=(salario*0.20);
	                salarion=(salario-impuesto);
		     	System.out.println("Su salario bruto acorde a las horas trabajadas y las tarifas establecidas es de: "+salario);
		     	System.out.println("Sus retenciones equivalen a: "+impuesto); 
		     	 System.out.println("Su salario neto es de: "+salarion); 
			 }    
	   
	   System.out.println("*********************************************************"); 
           System.out.println("Deseae realizar otro cálculo? Si (1), No(Cualquier número)");
            cont=sc.nextInt();
	}while(cont==1);
	
   System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
