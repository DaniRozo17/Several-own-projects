
package tallerpoo;
import java.util.Scanner;

public class programa6 {
     public void p6(){
       Scanner sc = new Scanner(System.in);
       double comision=0;
       System.out.println("Bienvenido el siguiente programa calcula las comisiones que debe recibir como trabajador acorde a sus ventas realizadas");
       System.out.println("Ingrese el numero de ventas que realizo:");
       int n = sc.nextInt();
       
       for(int i=0;i<n;i++)
       {
           System.out.println("Ingrese el valor de la venta "+(i+1)+":");
           double valor = sc.nextDouble();
           
           if(valor<=100000){
              comision=comision+((valor*10)/100);
             
           }
           else if(valor>100000){
               comision=comision+((valor*7)/100);
           }
           else{
               System.out.println("Ingrese un valor NO valido, intente de nuevo");
           }
       }
       System.out.println("lA CANTIDAD DE VENTAS FUERON: "+n);
       System.out.println("SU COMISION TOTAL COMO VENDEDOR ES DE: "+comision);
    }
    
}
