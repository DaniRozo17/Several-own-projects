
package tallerpoo;
import java.util.Scanner;

public class programa7 {
     public void p7(){
        Scanner sc = new Scanner(System.in);
         int n, m, k, l;
         double nota1, nota2, nota3, notaf, notasf=0, palumno, palumnos=0, pgrupo, pgrupos=0, totalgrupo;
         
        System.out.println("Bienvenido, el siguiente programa calcula el promedio de n grupos del mismo año escolar ");
        System.out.println("Cuantos grupos desea evaluar?: ");
         n=sc.nextInt();
    
    for(int i=0; i<n; i++) //ciclo para los grupos
    {
    	System.out.println("Grupo "+(i+1)+", cuantos alumnos desea evaluar?: ");
    	 m=sc.nextInt();
    	for(int j=0; j<m; j++) //ciclo para alumnos
    	{
    		System.out.println("Alumno "+(j+1)+", cuantas materias va a cursar?: "); //ciclo para materias
    		 k=sc.nextInt();
    		for(l=0; l<k; l++)
    		{
    			System.out.println("Materia "+(l+1)+", ingrese las 3 respectivas notas: ");
    			System.out.println("Nota 1: ");
    			 nota1=sc.nextDouble();
    			System.out.println("Nota 2: ");
    			 nota2=sc.nextDouble();
    			System.out.println("Nota 3: ");
    			 nota3=sc.nextDouble();
    			 
    			 notaf=((nota1+nota2+nota3)/3); //promedio de las notas de 1 materia
    			 notasf=(notasf+notaf); //suma de las notas de todas las materias
			}
			palumno=((notasf)/k); //promedio total de todas las materias
			System.out.println("Alumno "+(j+1)+", su promedio es de: "+palumno);
			palumnos=(palumnos+palumno); //suma de los promedios de cada estudiante
		}
		pgrupo=(palumnos/m); //proemdio del grupo
		System.out.println("Grupo "+(i+1)+", su promedio es de: "+pgrupo);
		pgrupos=(pgrupos+pgrupo); //promedios de cada grupo en total
	}	
	totalgrupo=(pgrupos/n);
    System.out.println("El promedio de TODOS los grupos es de: "+totalgrupo);
    
    System.out.println("****************************************");
    System.out.println("Gracias por usar el programa, feliz día"); //despedida
    }
}
