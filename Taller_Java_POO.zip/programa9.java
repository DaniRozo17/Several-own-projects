
package tallerpoo;
import static java.lang.StrictMath.exp;
import java.util.Scanner;

public class programa9 {
     public void p9(){
        Scanner sc = new Scanner(System.in);
        double x;

      System.out.println("Bienvenido, el siguiente programa calcula la función exponencial:  ");
      System.out.println("Definida como el número e o de Euler, elevado a un número x");
      System.out.println("Ingrese el exponente al que desea elevar: ");
       x=sc.nextDouble();
    
    double result = exp(x);
    System.out.println( "e^(x) = " + result);
    
   System.out.println("****************************************");
   System.out.println("Gracias por usar el programa, feliz día"); //despedida
    }
}
