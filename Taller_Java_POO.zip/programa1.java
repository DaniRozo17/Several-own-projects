
package tallerpoo;
import static java.lang.StrictMath.abs;
import java.util.Scanner;

public class programa1 {
    public void p1(){
      Scanner sc = new Scanner(System.in);
      int cont;	
      int i, op, operacion; 
      double consig, retir;
      double totconsig=0, cantconsig=0, totretiro=0, cantretiro=0, cuenta;   //Aqui declaro todas las variables que uso 
      
    do{
      System.out.println("***************************************");
      System.out.println("Bienvenido, este es un cajero automatico");  
	  System.out.println("***************************************"); 
	  System.out.println(" Cuantas operaciones desea realizar? ");
	  op=sc.nextInt();
	  
	  for(i=0; i<op; i++)
	  {
            System.out.println("Que operación desea realizar? ");
            System.out.println("1)Consignacion  2)Retiro \n Ingrese el número de la operacion: ");
             operacion=sc.nextInt();
      
            if(operacion==1) // cuando el cliente quiere consignar 
            {
      	      System.out.println("Bienvenido a CONSIGNACION"); 
      	      System.out.println("Ingrese el numero de cuenta al que va a consignar: ");
      	        cuenta=sc.nextDouble();
      	      System.out.println("Ingrese la cantidad de dinero a consignar: ");
      	        consig=sc.nextDouble();
      	        totconsig=totconsig+consig; 
      	        cantconsig=cantconsig+1;
               System.out.println("Cuenta: "+cuenta);
      	       System.out.println("Transaccion EXITOSA, gracias por usar el servicio");
      	       System.out.println("**************************************************");
	    }
	     else if(operacion==2) // cuando el cliente quiere retirar
	     {
	  	 System.out.println("Bienvenido a RETIRO"); 
      	         System.out.println("Ingrese el numero de cuenta del que va a retirar: ");
      	          cuenta=sc.nextDouble();
      	         System.out.println("Ingrese la cantidad de dinero a retirar: ");
      	          retir=sc.nextDouble();
      	          totretiro=totretiro+retir; 
      	          cantretiro=cantretiro+1;
                 System.out.println("Cuenta: "+cuenta);
                 System.out.println("Transacción EXITOSA, gracias por usar el servicio");
                 System.out.println("**************************************************");
	     }
	      else // cuando ingresa un número que NO es 
	      {
	  	 System.out.println("Ingreso un valor NO valido, por favor intente de nuevo");
	  	 System.out.println("******************************************************");
	      }
	  }
          
	 System.out.println("Total de dinero por consignaciones: "+totconsig);
	 System.out.println("Total de dinero por retiro: "+totretiro);
	 double diferencia=totconsig-totretiro;
	 System.out.println("Diferencia absoluta: "+(abs(diferencia)));
	 System.out.println("*************************************");
	 System.out.println("Cantidad de consignaciones realizadas: "+cantconsig); 
	 System.out.println("Cantidad de retiros realizados: "+cantretiro);
	 System.out.println("***************************************");
     System.out.println("Deseae realizar otro cálculo? Si (1), No(Cualquier número)");
      cont=sc.nextInt();
	}while(cont==1);
	
   System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
