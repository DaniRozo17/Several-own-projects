
package tallerpoo;
import java.util.Scanner;

public class programa2 {
     public void p2(){
      Scanner sc = new Scanner(System.in);
      int cont=1;	
      int i, n, sexo, edad, carrera, jornada;
      double estderecho=0, estingenieria=0, estingenieria2=0, edadmingenieria2=0, estcontaduria=0, estmujerm=0, edadmingenieria=0;
    
      do{
        System.out.println("Bienvenido, el siguiente programa calcula bajo ciertos criterios, promedios y porcentajes con respecto a la información de cierto número de estudiantes");
        System.out.println("Ingrese la cantidad de estudiantes a evaluar: ");
        n=sc.nextInt();
      
      for(i=0; i<n; i++)
      {
      	System.out.println("Estudiante "+(i+1)+", digite su sexo -> 1)Masculino 2)Femenino");
      	 sexo=sc.nextInt();
      	System.out.println("Digite su carrera 1)Ingenieria  2)Contaduria  3)Derecho  4)Otro");
      	 carrera=sc.nextInt();
      	System.out.println("Digite su jornada 1)Diurna  2)Nocturna");
      	 jornada=sc.nextInt();
        System.out.println("Digite su edad: ");
      	 edad=sc.nextInt();
      	
      	if(carrera==2)
      	{
      	  estcontaduria=estcontaduria+edad;
	}
	 else if(carrera==1 && sexo==1)
	 {
	    estingenieria=estingenieria+1;
	 }
      	  else if(sexo==2 && carrera==1)
      	  {
      	    edadmingenieria=estingenieria+edad;
      	    edadmingenieria2=edadmingenieria2+1;
	  }
	    else if(sexo==2 && edad<20)
	    {
		estmujerm=estmujerm+1;
	    }
	      else if(sexo==1 && edad>22 && carrera==3 && jornada==2)
	      {
		  estderecho=estderecho+1;
              }
        }
	 
	  System.out.println("El promedio de edad de estudiantes de contaduria es de: "+(estcontaduria/n)+"%");
	  System.out.println("El porcentaje de hombres en ingenieria es de: "+((estingenieria*100)/n)+"%");
	  System.out.println("El porcentaje de mujeres menores a 20 años en la universidad es de: "+((estmujerm*100)/n)+"%");
	  System.out.println("El promedio de edad de las mujeres en ingenieria es de: "+(edadmingenieria/edadmingenieria2));
	  System.out.println("El porcentaje de hombres mayores a 22 años que estudian derecho en la noche es de: "+((estderecho*100)/n)+"%");
	 
	 System.out.println("Deseae realizar otro cálculo? Si (1), No(Cualquier número)");
          cont=sc.nextInt();
	}while(cont==1);
      
      System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
