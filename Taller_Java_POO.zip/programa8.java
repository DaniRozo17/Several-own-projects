
package tallerpoo;
import java.util.Scanner;

public class programa8 {
     public void p8(){
        Scanner sc = new Scanner(System.in);
        
        String nombre;
        double edad, estatura, peso, cojos, cabello;
        int n, sexo;
	
	 System.out.println("Bienvenido, ingrese la cantidad de empleados a evaluar: ");
	  n=sc.nextInt();
	 
	for(int i=0; i<n; i++)
	{
	  System.out.println("***************************************************");
	  System.out.println("Empleado "+(i+1)+", complete los datos solicitados");
	  System.out.println("Ingrese su nombre: ");
	   nombre=sc.nextLine();
	  System.out.println("Ingrese su sexo: 1)Masculino 2)Femenino"); 
	   sexo=sc.nextInt();
	  System.out.println("Ingrese su edad: ");
	   edad=sc.nextDouble();
	  System.out.println("Ingrese su estatura en metros: ");
	   estatura=sc.nextDouble();
	  System.out.println("Ingrese su peso en libras: ");
	   peso=sc.nextDouble();
	  System.out.println("Ingrese su color de ojos: 1)Azul 2)Castaño 3)Otro");
	   cojos=sc.nextDouble();
	  System.out.println("Ingrese su color de cabello: 1)Castaño 2)Rubio 3)Otro");
	   cabello=sc.nextDouble();
	
	  if(sexo==2 && cojos==1 && cabello==2 && estatura>=1.65 && estatura<=1.75 && peso<120)
	  {
	       System.out.println("Señorita "+nombre+", cumple con ser mujer de cabello rubio y ojos azules, que mide entre 1.65 metros y 1.75 metros y que pese menos de 120 libras");
	  }
	    if(sexo==1 && cojos==2 && estatura>1.70 && peso>=180 && peso<=220)
	    {
	    	System.out.println("Señor "+nombre+", cumple con ser un hombre de ojos castaños de más de 1.70 metros de altura y que pesa entre 180 y 220 libras");
    	}
   }
    
   System.out.println("****************************************");
   System.out.println("Gracias por usar el programa, feliz día"); //despedida
    }
}
