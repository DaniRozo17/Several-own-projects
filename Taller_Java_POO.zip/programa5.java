
package tallerpoo;
import java.util.Scanner;

public class programa5 {
     public void p5(){
        Scanner sc = new Scanner(System.in);
        String nombre;
	int cont, hijos;
	double retencion, codigo, horast, tarifa, salario, salariot, subsidio, tpagar;
        
        do{
      
      System.out.println("Bienvenido empleado, a continuación ingrese los datos solicitados");
      System.out.println("Ingrese su codigo: ");
       codigo=sc.nextDouble();
      System.out.println("Ingrese su nombre: ");
       nombre=sc.nextLine();
      System.out.println("Ingrese el numero de hijos que tiene: ");
       hijos=sc.nextInt();
      System.out.println("Ingrese las horas trabajadas en el mes: ");
       horast=sc.nextDouble();
      System.out.println("Ingrese el salario por hora: ");
       tarifa=sc.nextDouble();
       
      salario = (horast*tarifa);
      subsidio = (hijos*17200);
      
      System.out.println(nombre+" , con codigo: "+codigo);
      System.out.println("Por subsidio de hijos recibe: $"+subsidio);
      
      //RETENCIONES CON LAS CONDICIONES DADAS
      if(salario<428000)    //Cuando gana menos de $428.000
      {
      	if(hijos>12)
      	{
      		System.out.println("No presenta retención");
      		tpagar=(salario+subsidio);
      		System.out.println("El total a pagar es de: "+tpagar);
		}
		 if(hijos<=12 && hijos>6)
		 {
		 	retencion=((12-hijos)/2);
			System.out.println("Presenta una retención del "+retencion+"% ");
			salariot=(salario-(salario*(retencion/100)));
			tpagar=(salariot+subsidio);
      		        System.out.println("El total a pagar es de: "+tpagar);
		 }
		  else if(hijos<=6)
		  {
		 	System.out.println("Presenta una retención del 4%"); 
		 	salariot=(salario-(salario*0.04));
		 	tpagar=(salariot+subsidio);
      		        System.out.println("El total a pagar es de: "+tpagar);
		  } 
	  }
  
      if(salario>=428000)    //Cuando gana mas de $428.000
      {
      	if(hijos<5)
      	{
      		System.out.println("Presenta retención del 5%");
      		retencion=(salario*0.05);
      		salariot=(salario-retencion);
      		tpagar=(salariot+subsidio);
      		System.out.println("El total a pagar es de: "+tpagar);
		}
		 if(hijos>=5 && hijos<10)
		 {
		 	retencion=(10/hijos);
		 	System.out.println("Presenta retención del "+retencion+"%");
		 	salariot=(salario-(salario*(retencion/100)));
		 	tpagar=(salariot+subsidio);
      		        System.out.println("El total a pagar es de: "+tpagar);
		 }
		  else if(hijos>10)
		  {
		  	System.out.println("No presenta retención");
		  	tpagar=(salario+subsidio);
      		        System.out.println("El total a pagar es de: "+tpagar);
		  }
	  }
	   
	   System.out.println("*********************************************************"); 
           System.out.println("Deseae evaluar otro empleado? Si (1), No(Cualquier número)");
            cont=sc.nextInt();
	}while(cont==1);
	
   System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
