
package tallerpoo;
import java.util.Scanner;

public class programa10 {
     public void p10(){
        Scanner sc = new Scanner(System.in);
        
        int cont=1;	
    
    
    do{
       int i, n, tipo, tipo1=0, tipo2=0, tipo3=0, valor, sexo;
       double id, comision, comiv, comist=0, comisionf=0;
       String nombre; 
	  
      System.out.println("Bienvenido, a continuación calcularemos su comisión como meser@ acorde a sus ventas realizadas");
      System.out.println("Ingrese su nombre: ");
       nombre=sc.nextLine();
      System.out.println("Ingrese su identificación: ");
       id=sc.nextDouble();
      System.out.println("Ingrese su sexo: 1) Hombre 2) Mujer  : ");
       sexo=sc.nextInt();
      System.out.println("Ingrese el número de ventas que realizo: ");
       n=sc.nextInt();
      
      for(i=0; i<n; i++)
      {
      	System.out.println("Ingrese el tipo de venta "+(i+1)+": 1)De contado  2) Cheque   3)Tarjeta credito ");
      	 tipo=sc.nextInt();
      	System.out.println("Ingrese el valor de la venta "+(i+1));
      	 valor=sc.nextInt();
      	 
      	 if(tipo==1)
      	 {
      	 	comision=(valor*0.7);
      	 	comiv=(valor*0.15);
      	 	comist=comision+comiv; 
      	 	tipo1=tipo1+1;
		 }
		 else if(tipo==2)
		 {
		 	comision=(valor*0.7);
		 	comiv=(valor*0.10);
		 	comist=comision+comiv; 
		 	tipo2=tipo2+1;
		 }
      	 else if(tipo==3)
      	 {
      	 	comision=(valor*0.7);
      	 	comiv=(valor*0.05);
      	 	comist=comision+comiv; 
      	 	tipo3=tipo3+1;
		 }
		 else
		 {
		 	System.out.println("Ingreso un valor NO valido, intente de nuevo");
		 }
		 comisionf=comisionf+comist;
	  }
     
     System.out.println("La cantidad de comisión a pagar al empleado es de: "+comisionf);
     System.out.println("Realizando "+tipo1+" ventas de contado, "+tipo2+" por cheque y "+tipo3+" por tarjeta de credito");
     System.out.println("**************************************************************************");
     System.out.println("Desea calcular la comisión de otro empleado? Si (1), No (Cualquier número)");
      cont=sc.nextInt();
	}while(cont==1);
	
    System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
