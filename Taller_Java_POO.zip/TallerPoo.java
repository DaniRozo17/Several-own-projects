//Estudiante: Daniel Josué Rozo Rodríguez
//Programación orientada a objetos 2023-1

package tallerpoo;
import java.util.Scanner;

public class TallerPoo {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Bienvenido, el siguiente menú le permitira ejecutar el programa de su preferencia");
        System.out.println("1)Cajero automatico (Consignaciones y retiros)");
        System.out.println("2)REstudiantes de la u (Datos con requerimientos dados)");
        System.out.println("3)Servicio de fumigacion");
        System.out.println("4)MOLINA CORPORATION - nomina");
        System.out.println("5)Retenciones de empresa");
        System.out.println("6)CONCORDIA - comisiones empleados");
        System.out.println("7)Promedio grupos de estudaiantes");
        System.out.println("8)Clasificacion de empleados");
        System.out.println("9)Funcion exponencial");
        System.out.println("10)Comisiones de meseros de un restaurante");
        System.out.println("Que operacion desea realizar?");
        int operacion=sc.nextInt();
        
        switch(operacion){
            case 1:
                if(operacion==1)
                {
                   programa1 prog1= new programa1();
                   prog1.p1();
                }
            case 2: 
                if(operacion==2)
                {
                   programa2 prog2= new programa2();
                   prog2.p2();
                }
            case 3:
                if(operacion==3)
                {
                   programa3 prog3= new programa3();
                   prog3.p3();
                }
            case 4: 
                if(operacion==4)
                {
                   programa4 prog4= new programa4();
                   prog4.p4();
                }
            case 5:
                if(operacion==5)
                {
                   programa5 prog5= new programa5();
                   prog5.p5();
                }
            case 6:
                if(operacion==6)
                {
                   programa6 prog6= new programa6();
                   prog6.p6();
                }
            case 7:
                if(operacion==7)
                {
                   programa7 prog7= new programa7();
                   prog7.p7();
                }
            case 8:
                if(operacion==8)
                {
                   programa8 prog8= new programa8();
                   prog8.p8();
                }
            case 9:
                if(operacion==9)
                {
                   programa9 prog9= new programa9();
                   prog9.p9();
                }
            case 10:
                if(operacion==10)
                {
                   programa10 prog10= new programa10();
                   prog10.p10();
                }
            default: 
                if(operacion>10)
                {
                System.out.println("Ingreso un valor NO VALIDO");
                }
        }
        

    }
    
}
