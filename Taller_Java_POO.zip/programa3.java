
package tallerpoo;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class programa3 {
     public void p3(){
        Scanner sc = new Scanner(System.in);
        int cont, tfumig;
        double exc1, descuento, exceso, vfinal=0, vcobrar=0, hectareas;
        String nombre;
        
        do{
          System.out.println("Bienvenido, el siguiente programa calcula los valores a cobrar a un granjero \n por un tipo especifico de fumigación y acorde a la cantidad de hectareas a fumigar ");
          System.out.println("Ingrese su nombre: ");
           nombre=sc.nextLine();
          System.out.println(nombre+" los tipos de fumigación son: ");
	  System.out.println("Tipo 1: fumigación contra malas hierbas, 10 dólares por hectárea");
          System.out.println("Tipo 2: fumigación contra langostas, 15 dólares por hectárea");
	  System.out.println("Tipo 3: fumigación contra gusanos, 20 dólares por hectárea");
          System.out.println("Tipo 4: fumigación contra todo lo anterior, 30 dólares por hectárea");
	  System.out.println("Que tipo desea solicitar? (INGRESE NUMERO): ");
	   tfumig=sc.nextInt();
	  System.out.println("Cuantas hectareas va a fumigar?: ");
	   hectareas=sc.nextDouble();
	  
	   if(tfumig==1)
	   {
	  	 vcobrar=(10*hectareas);
	   } 
	    if(tfumig==2)
	    {
	  	  vcobrar=(15*hectareas);
	    }
	     if(tfumig==3)
	     {
	  	   vcobrar=(20*hectareas);
	     }
	      if(tfumig==4)
	      {
	  	    vcobrar=(30*hectareas);
	      }
	  System.out.println("-------------------------------------------------------------------------------------------");
	  System.out.println(vcobrar); 
	  if(hectareas>1000 && hectareas>1000 && vcobrar>3000)
	  {
	  	descuento=(vcobrar*0.05);
	  	vfinal=(vcobrar-descuento);
	  }
           else if(vcobrar>3000)
	   {
	  	 exceso=(vcobrar-3000);
                 exc1=(exceso*0.10);
	  	 vfinal=(exceso-exc1);
	   }
      
      System.out.println("Aspirante "+nombre+" el valor a pagar por el servicio es de: "+vfinal+" dolares");
      System.out.println("Deseae realizar otro cálculo? Si (1), No(Cualquier número)");
       cont=sc.nextInt();
	}while(cont==1);
	
    System.out.println("\t Gracias por usar el programa, feliz día"); //despedida
    }
}
