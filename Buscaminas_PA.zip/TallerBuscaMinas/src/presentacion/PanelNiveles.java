package presentacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelNiveles extends JPanel {
	
	private Modelo modelo;
	private int filas = 0;
	private int columnas = 0;
	private JButton[][] botonesTablero; 
	
	public PanelNiveles(Modelo m) {

		modelo = m;
		
		filas = m.obtenerTablero().getNumeroFilas();
		columnas = m.obtenerTablero().getNumeroColumnas();
		setSize(new Dimension(800, 500));
		setBackground(new Color(176, 176, 176, 255));
		setLayout(new GridLayout(filas,columnas));

		inicializarComponentes();

		setVisible(false);

	}
	
	public void inicializarComponentes() {
		
		botonesTablero = new JButton[filas][columnas];
		for (int i = 0; i < botonesTablero.length; i++) {
			for (int j = 0; j < botonesTablero[i].length; j++) {
				botonesTablero[i][j] = new JButton();
				botonesTablero[i][j].setName(i + "," + j);
				add(botonesTablero[i][j]);
			}
		}
	}

	public Modelo getModelo() {
		return modelo;
	}

	public void setModelo(Modelo modelo) {
		this.modelo = modelo;
	}

	public int getFilas() {
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	public int getColumnas() {
		return columnas;
	}

	public void setColumnas(int columnas) {
		this.columnas = columnas;
	}

	public JButton[][] getBotonesTablero() {
		return botonesTablero;
	}

	public void setBotonesTablero(JButton[][] botonesTablero) {
		this.botonesTablero = botonesTablero;
	}
	
}
