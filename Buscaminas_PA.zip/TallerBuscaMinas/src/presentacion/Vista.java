package presentacion;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Vista extends JFrame {

	private Modelo model;
	private Controlador control;
	private JMenu menuprincipal;
	private JMenuBar menubar;
	private JMenuItem nivel1;
	private JMenuItem nivel2;
	private JMenuItem nivel3;
	private JMenuItem nivelPersonalizado;
	private PanelDatosPersonalizado panelDatos;
	private PanelNiveles panelNiveles;

	public Vista(Modelo m) {

		model = m;
		setTitle("Buscaminas");
		setSize(800, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(new Color(78, 213, 250));
		getContentPane().setLayout(new BorderLayout(10, 10));

		inicializarComponentes();
		capturarEventos();

		setResizable(true);
		setLocationRelativeTo(null);

	}

	public void inicializarComponentes() {

		menubar = new JMenuBar();
		setJMenuBar(menubar);
		menuprincipal = new JMenu("Niveles");
		menubar.add(menuprincipal);

		nivel1 = new JMenuItem("Nivel 1");
		menuprincipal.add(nivel1);

		nivel2 = new JMenuItem("Nivel 2");
		menuprincipal.add(nivel2);

		nivel3 = new JMenuItem("Nivel 3");
		menuprincipal.add(nivel3);

		nivelPersonalizado = new JMenuItem("Nivel Personalizado");
		menuprincipal.add(nivelPersonalizado);

		panelDatos = new PanelDatosPersonalizado();
		getContentPane().add(panelDatos, BorderLayout.NORTH);

	}

	public Controlador getControl() {
		if (control == null) {
			control = new Controlador(this);
		}
		return control;
	}

	public void capturarEventos() {

		nivel1.addActionListener(getControl());
		nivel2.addActionListener(getControl());
		nivel3.addActionListener(getControl());
		nivelPersonalizado.addActionListener(getControl());
		panelDatos.getBtnCancelar().addActionListener(getControl());
		panelDatos.getBtnGenerar().addActionListener(getControl());

	}

	public void mostramensaje(String mensaje) {

		JOptionPane.showMessageDialog(null, mensaje);
	}

	public void mostrarTablero() {
		panelNiveles = new PanelNiveles(model);
		System.out.println("TABLERO");
		System.out.println(model.obtenerTablero().getNumeroFilas());
		System.out.println(model.obtenerTablero().getNumeroColumnas());
		getContentPane().add(panelNiveles, BorderLayout.CENTER);
		for (int i = 0; i < getPanelNiveles().getBotonesTablero().length; i++) {
			for (int j = 0; j < getPanelNiveles().getBotonesTablero()[i].length; j++) {
				getPanelNiveles().getBotonesTablero()[i][j].addActionListener(getControl());
			}

		}
		panelNiveles.setVisible(true);

	}

	public JMenu getMenuprincipal() {
		return menuprincipal;
	}

	public void setMenuprincipal(JMenu menuprincipal) {
		this.menuprincipal = menuprincipal;
	}

	public JMenuBar getMenubar() {
		return menubar;
	}

	public void setMenubar(JMenuBar menubar) {
		this.menubar = menubar;
	}

	public JMenuItem getNivel1() {
		return nivel1;
	}

	public void setNivel1(JMenuItem nivel1) {
		this.nivel1 = nivel1;
	}

	public JMenuItem getNivel2() {
		return nivel2;
	}

	public void setNivel2(JMenuItem nivel2) {
		this.nivel2 = nivel2;
	}

	public JMenuItem getNivel3() {
		return nivel3;
	}

	public void setNivel3(JMenuItem nivel3) {
		this.nivel3 = nivel3;
	}

	public JMenuItem getNivelPersonalizado() {
		return nivelPersonalizado;
	}

	public void setNivelPersonalizado(JMenuItem nivelPersonalizado) {
		this.nivelPersonalizado = nivelPersonalizado;
	}

	public PanelDatosPersonalizado getPanelDatos() {
		return panelDatos;
	}

	public void setPanelDatos(PanelDatosPersonalizado panelDatos) {
		this.panelDatos = panelDatos;
	}

	public void setControl(Controlador control) {
		this.control = control;
	}

	public Modelo getModel() {
		return model;
	}

	public void setModel(Modelo model) {
		this.model = model;
	}

	public PanelNiveles getPanelNiveles() {
		return panelNiveles;
	}

	public void setPanelNiveles(PanelNiveles panelNiveles) {
		this.panelNiveles = panelNiveles;
	}

}
