package presentacion;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelDatosPersonalizado extends JPanel {

	private JLabel labelFilas;
	private JLabel labelColumnas;
	private JLabel labelMinas;
	private JTextField textFilas;
	private JTextField textColumnas;
	private JTextField textMinas;
	private JButton btnGenerar;
	private JButton btnCancelar;
	
	public PanelDatosPersonalizado() {

		setPreferredSize(new Dimension(800,50));
		setLayout(new GridLayout(1,4,10,10));

		inicializarComponentes();

		setVisible(false);

	}
	
	public void inicializarComponentes() {
		
		JPanel aux = new JPanel();
		labelFilas = new JLabel("Filas: ");
		aux.add(labelFilas);
		
		textFilas = new JTextField(10);
		textFilas.setSize(new Dimension(10, 10));
		aux.add(textFilas);
		
		add(aux);
		
		JPanel aux2 = new JPanel();
		labelColumnas = new JLabel("Columnas: ");
		aux2.add(labelColumnas);
		
		textColumnas = new JTextField(10);
		textColumnas.setSize(new Dimension(10, 10));
		aux2.add(textColumnas);
		
		add(aux2);
		
		JPanel aux3 = new JPanel();
		labelMinas = new JLabel("Minas: ");
		aux3.add(labelMinas);
		
		textMinas = new JTextField(10);
		textMinas.setSize(new Dimension(10, 10));
		aux3.add(textMinas);
		
		add(aux3);
		
		JPanel aux4 = new JPanel();
		btnGenerar = new JButton("Generar");
		aux4.add(btnGenerar);
		
		btnCancelar = new JButton("Cancelar");
		aux4.add(btnCancelar);
		
		add(aux4);
		
	}

	public JLabel getLabelFilas() {
		return labelFilas;
	}

	public void setLabelFilas(JLabel labelFilas) {
		this.labelFilas = labelFilas;
	}

	public JLabel getLabelColumnas() {
		return labelColumnas;
	}

	public void setLabelColumnas(JLabel labelColumnas) {
		this.labelColumnas = labelColumnas;
	}

	public JLabel getLabelMinas() {
		return labelMinas;
	}

	public void setLabelMinas(JLabel labelMinas) {
		this.labelMinas = labelMinas;
	}

	public JTextField getTextFilas() {
		return textFilas;
	}

	public void setTextFilas(JTextField textFilas) {
		this.textFilas = textFilas;
	}

	public JTextField getTextColumnas() {
		return textColumnas;
	}

	public void setTextColumnas(JTextField textColumnas) {
		this.textColumnas = textColumnas;
	}

	public JTextField getTextMinas() {
		return textMinas;
	}

	public void setTextMinas(JTextField textMinas) {
		this.textMinas = textMinas;
	}

	public JButton getBtnGenerar() {
		return btnGenerar;
	}

	public void setBtnGenerar(JButton btnGenerar) {
		this.btnGenerar = btnGenerar;
	}

	public JButton getBtnCancelar() {
		return btnCancelar;
	}

	public void setBtnCancelar(JButton btnCancelar) {
		this.btnCancelar = btnCancelar;
	}
	
}
