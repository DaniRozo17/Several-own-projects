package presentacion;

import logica.Tablero;

public class Modelo {

	private Vista ventana;
	private Tablero tablero;

	public Vista getMiVentana() {
		if (ventana == null) {
			ventana = new Vista(this);
		}
		return ventana;
	}

	public void setTablero(Tablero tablero) {
		this.tablero = tablero;
	}
	
	

	public Tablero getTablero(int filas, int columnas, int minas) {
		if (tablero == null) {

			tablero = new Tablero(filas, columnas, minas);
			tablero.imprimir();
			System.out.println("PISTAS");
			tablero.imprimirPistas();

		}
		return tablero;
	}
	
	public Tablero obtenerTablero() {
		return tablero;
	}

	public void iniciar() {
		getMiVentana().setSize(800, 500);
		getMiVentana().setVisible(true);
	}

	public void capturarDatosTablero() {
		int filas = 0;
		int columnas = 0;
		int minas = 0;

		try {
			filas = Integer.parseInt(getMiVentana().getPanelDatos().getTextFilas().getText());
			columnas = Integer.parseInt(getMiVentana().getPanelDatos().getTextColumnas().getText());
			minas = Integer.parseInt(getMiVentana().getPanelDatos().getTextMinas().getText());

			if (filas < 6 || columnas < 6) {

				getMiVentana().mostramensaje("El tablero debe ser de minimo 6x6");
				getMiVentana().getPanelDatos().getTextFilas().setText("");
				getMiVentana().getPanelDatos().getTextColumnas().setText("");
				getMiVentana().getPanelDatos().getTextMinas().setText("");

			} else if (filas > 40 || columnas > 40) {

				getMiVentana().mostramensaje("El tablero debe ser de maximo 40x40");
				getMiVentana().getPanelDatos().getTextFilas().setText("");
				getMiVentana().getPanelDatos().getTextColumnas().setText("");
				getMiVentana().getPanelDatos().getTextMinas().setText("");

			} else if (minas < 2) {

				getMiVentana().mostramensaje("El minimo de minas debe ser 2");
				getMiVentana().getPanelDatos().getTextFilas().setText("");
				getMiVentana().getPanelDatos().getTextColumnas().setText("");
				getMiVentana().getPanelDatos().getTextMinas().setText("");

			} else if (minas > (filas * columnas) - 1) {

				getMiVentana().mostramensaje("El maximo de minas deber ser menor al numero de celdas");
				getMiVentana().getPanelDatos().getTextFilas().setText("");
				getMiVentana().getPanelDatos().getTextColumnas().setText("");
				getMiVentana().getPanelDatos().getTextMinas().setText("");

			} else {

				setTablero(null);
				getTablero(filas, columnas, minas);
				getMiVentana().getPanelDatos().setVisible(false);
				if(getMiVentana().getPanelNiveles() != null) {
					getMiVentana().getPanelNiveles().setVisible(false);
					}
				getMiVentana().mostrarTablero();
				
			}

		} catch (Exception e) {
			getMiVentana().mostramensaje("Error: solo se permiten digitos numericos");
			getMiVentana().getPanelDatos().getTextFilas().setText("");
			getMiVentana().getPanelDatos().getTextColumnas().setText("");
			getMiVentana().getPanelDatos().getTextMinas().setText("");
		}

	}

}
