package presentacion;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Controlador implements ActionListener {

	private Vista vista;
	// private String posiciones[] = new String[2];

	public Controlador(Vista athis) {

		vista = athis;

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() instanceof JMenuItem) {
			if (e.getSource().equals(vista.getNivel1())) {

				// System.out.println("NIVEL 1");
				int filas = 8;
				int columnas = 8;
				int minas = 10;
				vista.getModel().setTablero(null);
				vista.getModel().getTablero(filas, columnas, minas);
				if (vista.getPanelNiveles() != null) {
					vista.getPanelNiveles().setVisible(false);
				}
				vista.mostrarTablero();

			} else if (e.getSource().equals(vista.getNivel2())) {

				// System.out.println("NIVEL 2");
				int filas = 16;
				int columnas = 16;
				int minas = 40;
				vista.getModel().setTablero(null);
				vista.getModel().getTablero(filas, columnas, minas);
				if (vista.getPanelNiveles() != null) {
					vista.getPanelNiveles().setVisible(false);
				}
				vista.mostrarTablero();

			} else if (e.getSource().equals(vista.getNivel3())) {

				// System.out.println("NIvel 3");
				int filas = 16;
				int columnas = 30;
				int minas = 99;
				vista.getModel().setTablero(null);
				vista.getModel().getTablero(filas, columnas, minas);
				if (vista.getPanelNiveles() != null) {
					vista.getPanelNiveles().setVisible(false);
				}
				vista.mostrarTablero();

			} else if (e.getSource().equals(vista.getNivelPersonalizado())) {

				// System.out.println("PERSONALIZADO");
				if (vista.getPanelNiveles() != null) {
					vista.getPanelNiveles().setVisible(false);
				}
				vista.getPanelDatos().setVisible(true);

			}

		} else if (e.getSource() instanceof JButton) {

			if (e.getSource().equals(vista.getPanelDatos().getBtnCancelar())) {

				vista.getPanelDatos().setVisible(false);

			} else if (e.getSource().equals(vista.getPanelDatos().getBtnGenerar())) {

				vista.getModel().capturarDatosTablero();

			} else {
				for (int i = 0; i < vista.getPanelNiveles().getBotonesTablero().length; i++) {
					for (int j = 0; j < vista.getPanelNiveles().getBotonesTablero()[i].length; j++) {
						if (e.getSource().equals(vista.getPanelNiveles().getBotonesTablero()[i][j])) {
							String[] posiciones = vista.getPanelNiveles().getBotonesTablero()[i][j].getName()
									.split(",");
							int posFila = Integer.parseInt(posiciones[0]);
							int posColumna = Integer.parseInt(posiciones[1]);
							if (vista.getModel().obtenerTablero().getCeldas()[posFila][posColumna].getTieneMina()) {

								juegoPerdido();

							} else {

								generarPistas(posFila, posColumna);

							}

						}
					}
				}

			}

		}

	}

	public void juegoPerdido() {

		for (int i = 0; i < vista.getModel().obtenerTablero().getCeldas().length; i++) {
			for (int j = 0; j < vista.getModel().obtenerTablero().getCeldas()[i].length; j++) {
				vista.getPanelNiveles().getBotonesTablero()[i][j].setEnabled(false);
				if (vista.getModel().obtenerTablero().getCeldas()[i][j].getTieneMina()) {

					vista.getPanelNiveles().getBotonesTablero()[i][j].setText(String.valueOf("*"));
					vista.getPanelNiveles().getBotonesTablero()[i][j].setFont(new Font("ARIAL", Font.BOLD, 18));
				}
			}
		}
		vista.mostramensaje("HAS PERDIDO");
	}

	public void generarPistas(int fila, int columna) {

		if (vista.getModel().obtenerTablero().getCeldas()[fila][columna].getMinasCercanas() != 0) {

			vista.getPanelNiveles().getBotonesTablero()[fila][columna].setText(
					String.valueOf(vista.getModel().obtenerTablero().getCeldas()[fila][columna].getMinasCercanas()));
			vista.getPanelNiveles().getBotonesTablero()[fila][columna].setEnabled(false);
			vista.getModel().obtenerTablero().getCeldas()[fila][columna].setCeldaVisible(false);

		} else {

			ArrayList<String> celdasEncontradas = new ArrayList<>();
			celdasEncontradas.add(vista.getPanelNiveles().getBotonesTablero()[fila][columna].getName());
			vista.getPanelNiveles().getBotonesTablero()[fila][columna].setEnabled(false);
			for (int i = 0; i < celdasEncontradas.size(); i++) {
				System.out.println(celdasEncontradas.get(i));

				for (int j = 0; j < 8; j++) {

					int posTempFila = fila;
					int posTemColumna = columna;
					
					if (i > 0) {

						String[] posiciones = celdasEncontradas.toString().split(",");
						posTempFila = Integer.parseInt(posiciones[0].replace("[", ""));
						posTemColumna = Integer.parseInt(posiciones[1]);
						System.out.println(posTempFila);
						System.out.println(posTemColumna);
					}
					
					switch (j) {

					case 0:
						posTempFila--;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 1:
						posTempFila--;
						posTemColumna++;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 2:
						posTemColumna++;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 3:
						posTemColumna++;
						posTempFila++;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 4:
						posTempFila++;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 5:
						posTempFila++;
						posTemColumna--;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 6:
						posTemColumna--;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;
					case 7:
						posTempFila--;
						posTemColumna--;
						if (posTempFila >= 0 && posTempFila < vista.getModel().obtenerTablero().getCeldas().length
								&& posTemColumna >= 0
								&& posTemColumna < vista.getModel().obtenerTablero().getCeldas()[0].length) {

							if (vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.getMinasCercanas() == 0
									&& vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
											.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()) {

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);
								vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
										.setCeldaVisible(false);
								celdasEncontradas
										.add(vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
												.getName());

							} else if(vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
									.isCeldaVisible() && !vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna].getTieneMina()){

								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna].setText(String.valueOf(
										vista.getModel().obtenerTablero().getCeldas()[posTempFila][posTemColumna]
												.getMinasCercanas()));
								vista.getPanelNiveles().getBotonesTablero()[posTempFila][posTemColumna]
										.setEnabled(false);

							}

						}
						break;

					}
				}
			}

		}

	}

}
