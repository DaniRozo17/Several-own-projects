package persistencia;

public class Celda {

	private int columna;
	private int fila;
	private boolean tieneMina;
	private int minasCercanas;
	private boolean celdaVisible;
	
	
	public Celda(int columna, int fila) {
		this.columna = columna;
		this.fila = fila;
		celdaVisible = true;
	}
	
	public void incrementarNumeroMinasCercanas() {
		
		this.minasCercanas++;
		
	}
	
	public int getColumna() {
		return columna;
	}
	public void setColumna(int columna) {
		this.columna = columna;
	}
	public int getFila() {
		return fila;
	}
	public void setFila(int fila) {
		this.fila = fila;
	}
	
	public boolean getTieneMina() {
		return tieneMina;
	}

	public void setTieneMina(boolean tieneMina) {
		this.tieneMina = tieneMina;
	}

	public int getMinasCercanas() {
		return minasCercanas;
	}

	public void setMinasCercanas(int minasCercanas) {
		this.minasCercanas = minasCercanas;
	}

	public boolean isCeldaVisible() {
		return celdaVisible;
	}

	public void setCeldaVisible(boolean celdaVisible) {
		this.celdaVisible = celdaVisible;
	}
	
}
