import presentacion.Modelo;

public class Main {

	private Modelo model;
	
	public Main() {
		
		model = new Modelo();
		model.iniciar();
		
	}
	
	public static void main(String[] args) {
		new Main();
	}

}
