package logica;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import persistencia.Celda;

public class Tablero {

	private Celda[][] celdas;
	private int numeroFilas;
	private int numeroColumnas;
	private int numeroDeMinas;

	public Tablero(int numeroFilas, int numeroColumnas, int numMinas) {
		this.numeroFilas = numeroFilas;
		this.numeroColumnas = numeroColumnas;
		numeroDeMinas = numMinas;
		inicializarCeldas();
	}

	public void inicializarCeldas() {
		celdas = new Celda[this.numeroFilas][this.numeroColumnas];
		for (int i = 0; i < celdas.length; i++) {
			for (int j = 0; j < celdas[i].length; j++) {
				celdas[i][j] = new Celda(i, j);
			}
		}
		generarMinas();
	}

	public void generarMinas() {

		int minasGeneradas = 0;
		while (minasGeneradas != numeroDeMinas) {
			int posicionFila = (int) (Math.random() * celdas.length);
			int posicionColumna = (int) (Math.random() * celdas[0].length);
			if (!celdas[posicionFila][posicionColumna].getTieneMina()) {

				celdas[posicionFila][posicionColumna].setTieneMina(true);
				minasGeneradas++;
			}
		}
		calcularNumeroMinasCercanas();

	}

	public void calcularNumeroMinasCercanas() {

		for (int i = 0; i < celdas.length; i++) {
			for (int j = 0; j < celdas[i].length; j++) {

				if (celdas[i][j].getTieneMina()) {
					List<Celda> minasCercanas = obtenerCeldasCercanas(i, j);
					minasCercanas.forEach((c) -> c.incrementarNumeroMinasCercanas());
				}

			}
		}

	}

	public List<Celda> obtenerCeldasCercanas(int posicionFila, int posicionColumna) {
		List<Celda> listaCeldas = new LinkedList<>();

		for (int i = 0; i < 8; i++) {

			int posFila = posicionFila;
			int posColumna = posicionColumna;
			switch (i) {

			case 0:
				posFila--;
				break;
			case 1:
				posFila--;
				posColumna++;
				break;
			case 2:
				posColumna++;
				break;
			case 3:
				posColumna++;
				posFila++;
				break;
			case 4:
				posFila++;
				break;
			case 5:
				posFila++;
				posColumna--;
				break;
			case 6:
				posColumna--;
				break;
			case 7:
				posFila--;
				posColumna--;
				break;

			}
			if (posFila >= 0 && posFila < this.celdas.length && posColumna >= 0 && posColumna < this.celdas[0].length) {
				listaCeldas.add(this.celdas[posFila][posColumna]);
			}
		}

		return listaCeldas;

	}

	public void imprimir() {

		for (int i = 0; i < celdas.length; i++) {
			for (int j = 0; j < celdas[i].length; j++) {
				System.out.print(celdas[i][j].getTieneMina() ? "*" : "0");
			}
			System.out.println("");
		}

	}

	public void imprimirPistas() {

		for (int i = 0; i < celdas.length; i++) {
			for (int j = 0; j < celdas[i].length; j++) {
				if(!celdas[i][j].getTieneMina()) {
				System.out.print(celdas[i][j].getMinasCercanas());
				} else {
					System.out.print("*");
				}
			}
			System.out.println("");
		}

	}
	
	

	public Celda[][] getCeldas() {
		return celdas;
	}

	public void setCeldas(Celda[][] celdas) {
		this.celdas = celdas;
	}

	public int getNumeroFilas() {
		return numeroFilas;
	}

	public void setNumeroFilas(int numeroFilas) {
		this.numeroFilas = numeroFilas;
	}

	public int getNumeroColumnas() {
		return numeroColumnas;
	}

	public void setNumeroColumnas(int numeroColumnas) {
		this.numeroColumnas = numeroColumnas;
	}

}
